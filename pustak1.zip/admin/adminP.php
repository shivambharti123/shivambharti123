<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
	
if(isset($_POST['submit']))
{
	$name=$_POST['fName'];
	$_SESSION['collegeName']=$clgname=$_POST['cName'];
	$cAddress=$_POST['cAddress'];
	$profileimage1=$_FILES["clgPhoto"]["name"];
	
//for getting product id
$query=mysqli_query($con,"select max(id) as pid from clgInfo");
	$result=mysqli_fetch_array($query);
	 $productid=$result['pid']+1;
	$dir="bookimages/$productid";
if(!is_dir($dir)){
		mkdir("bookimages/".$productid);
	}

	move_uploaded_file($_FILES["clgPhoto"]["tmp_name"],"collegePhoto/$productid/".$_FILES["clgPhoto"]["name"]);

$sql=mysqli_query($con,"insert into clgInfo(fName,cName,cAddress,clgPhoto) values('$name','$clgname','$cAddress','$profileimage1')");
$_SESSION['msg']="Product Inserted Successfully !!";

}

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin| Profile</title>
	<link type="text/css" href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<link type="text/css" href="bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
	<link type="text/css" href="css/theme.css" rel="stylesheet">
	<link type="text/css" href="images/icons/css/font-awesome.css" rel="stylesheet">
	
	<link type="text/css" href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600' rel='stylesheet'>
	<script type="text/javascript">

</script>
</head>
<body>
<?php include('include/header.php');?>

<div class="wrapper">
		<div class="container">
			<div class="row">
<?php include('include/sidebar.php');?>				
			<div class="span9">
					<div class="content">
					<h3>Profile</h3>
					
				

<div class="profile">
<form class="form">


  <fieldset>
    <ul class="form--horizontal">
	<li>
        </label>
        <section class="form__controls">
		  <input type="image" name="fileToUpload" src= "images/building.png" width="100" height="100" <button type="button" class="btn btn-secondary" data-toggle="tooltip" data-placement="top" title="Upload College Photos"> -->
			  
     <input type="file" name="clgPhoto" id="my_file" style="display: none;" /> 
	 <span id="pro" class="text-danger font-weight-bold"></span>

        </section>
      </li> <br>
      <li>
        <label for="firstname">Name 
        </label>
        <section class="form__controls">
          <input type="text" Placeholder="Enter Name" id="fName" name="fName" class="form__element" />
		  <span id="name" class="text-danger font-weight-bold"></span>
        </section>
      </li>
      <li>
	  <label for="firstname">College Name 
        </label>
        <section class="form__controls">
          <input type="text" Placeholder="Enter College Name" id="cName" name="cName" class="form__element" />
		  <span id="clgname" class="text-danger font-weight-bold"></span>
        </section>
      </li>
       <li>
        <label for="message" >Address</label>
         <section class="form__controls">
          <textarea name="" palceholder="Enter Address" id="cAddress" name="cAddress" cols="30" rows="3" class="form__element"></textarea>
		  <span id="add" class="text-danger font-weight-bold"></span>
        </section>
      </li>
    
      
        <section class="form__controls action">
          <button  name="update" name="submit" id="insert" class="btn btn-default">Insert</button>
		  <button name="update" id="update" class="btn btn-default">Update</button>

        </section>
      

	  
        <section class="form__controls action">
        </section>
      
    </ul>
    
  </fieldset>
</form>    
</div>
						
					</div><!--/.content-->
				</div><!--/.span9-->
			</div>
		</div><!--/.container-->
	</div><!--/.wrapper-->

<?php include('include/footer.php');?>

	<script src="scripts/jquery-1.9.1.min.js" type="text/javascript"></script>
	<script src="scripts/jquery-ui-1.10.1.custom.min.js" type="text/javascript"></script>
	<script src="bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="scripts/flot/jquery.flot.js" type="text/javascript"></script>

	<script>
   var name = document.getElementById("fName");
   var cname = document.getElementById("cName");
   var address = document.getElementById("cAddress");
   var profile = document.getElementById("my_file");

if( name == ""){

              document.getElementById("name").innerHTML = "Please enter name!";
              return false;   
          } 

		  if(cname == ""){

              document.getElementById("clgname").innerHTML = "Please enter College name!";
              return false;   
          }
		  if( address == ""){

              document.getElementById("add").innerHTML = "Please enter Address!";
              return false;   
          }
		  if( profile == ""){

              document.getElementById("pro").innerHTML = "Please upload your College Photo!";
              return false;   
          }

//	 var tag = document.getElementsByTagName("h3");
	// var upload = document.getElementsByTagName("upload");


// tag.onclick = $('h3').replaceWith("<input placeholder='this is input'>" + "<br>" );
 // upload.onclick = $('img').replaceWith("<input type='file' src='images/user.png' id='imgInp'><img src='images/user.png' id='upload' class='mx-auto d-block' style='width:10%'  /></input>");

	</script>
</body>

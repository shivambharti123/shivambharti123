<?php
$con = mysqli_connect("localhost","root","","datatable");
$query = mysqli_query($con, "SELECT * FROM products");
?>

<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	#message{
		display:none;
		font:Tahoma, Geneva, sans-serif;
		font-size:18px;
		color:#ccc;
		text-align:center;
		width:150px;
		border:1px solid #ccc;
		background:#000;
		position:absolute;
		left:45%;
		top:25%;
		padding:10px;
		opacity:.5;
		border-radius:5px;
	}
</style>
<link type="text/css" rel="stylesheet" href="media/css/jquery.dataTables.min.css"><!--for datatable-->
<link type="text/css" rel="stylesheet" href="media/css/jquery.dataTables_themeroller"><!--for datatable-->
<link type="text/css" rel="stylesheet" href="media/js/index.css"><!--for editTable-->
<script type="text/javascript" src="media/js/jquery.js"></script><!--for datatable-->
<script type="text/javascript" src="media/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="media/js/mindmup-editabletable.js"></script><!--for editTable-->
<script type="text/javascript" src="media/js/numeric-input-example.js"></script><!--for editTable-->
<script type="text/javascript">
$(document).ready(function(){
	//For datatable
	$('#datatables').dataTable({
		"scrollY":        "300px",
        "scrollCollapse": true,
        "paging":         false
	});
	//To update edited table
	$('#datatables').editableTableWidget();
	
	$('table td').on('change', function() {
		var column = $(this).attr('id'),
			id = $(this).closest('tr').attr('id'),
			newValue = $(this).text()
			
		$.post('update.php?edit&', {column: column, id: id, newValue: newValue});
		$('#message').fadeIn();
		$('#message').fadeOut(4000);
	});
});
</script>
<title>Datatable</title>
</head>
<body>
<table id="datatables" class="display">
	<thead>
	<tr>
		<th>Description</th>
        <th>Category</th>
        <th>Cost</th>
        <th>Price</th>
        <th>Critical Level</th>
	</tr>
    </thead>
    <tbody>
    <?php
    	while($row = mysqli_fetch_array($query)){
	?>
    	<tr id="<?php echo $row['id']; ?>">
        	<td id="description"><?php echo $row['description']; ?></td>
            <td id="category"><?php echo $row['category']; ?></td>
            <td id="cost"><?php echo $row['cost']; ?></td>
            <td id="price"><?php echo $row['price']; ?></td>
            <td id="critical_level"><?php echo $row['critical_level']; ?></td>
        </tr>
	<?php
		}
	?>
    </tbody>
</table>
<div id="message">Updated...</div>
</body>
</html>